# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['apache-airflow-providers-nz',
 'apache-airflow-providers-nz.hooks',
 'apache-airflow-providers-nz.operators']

package_data = \
{'': ['*']}

install_requires = \
['apache-airflow-providers-common-sql>=1.1.0,<2.0.0',
 'apache-airflow>=2.2.0,<3.0.0',
 'nzpy>=1.13.2,<2.0.0']

setup_kwargs = {
    'name': 'apache-airflow-providers-nz',
    'version': '1.0.0',
    'description': 'Airflow Hook for Netezza',
    'long_description': None,
    'author': 'Sanjay Renduchintala',
    'author_email': 'san8055@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
