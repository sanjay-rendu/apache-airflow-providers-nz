# Airflow Hook for Netezza

Install this package in the python environment with Airflow to use the Netezza Hook.

Installation: `pip install https://github.com/sanjay-rendu/apache-airflow-providers-nz/raw/main/dist/airflownz-1.0.0-py3-none-any.whl`


More about creating your own provider packages - https://airflow.apache.org/docs/apache-airflow-providers/index.html#how-to-create-your-own-provider
