# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['airflownz', 'airflownz.hooks', 'airflownz.operators']

package_data = \
{'': ['*']}

install_requires = \
['apache-airflow-providers-common-sql>=1.1.0,<2.0.0',
 'apache-airflow>=2.2.0,<3.0.0',
 'nzpy>=1.13.2,<2.0.0']

entry_points = \
{'apache_airflow_provider': ['provider_info = '
                             'airflownz.provider_info:get_provider_info']}

setup_kwargs = {
    'name': 'airflownz',
    'version': '1.0.0',
    'description': 'Airflow Hook for Netezza',
    'long_description': None,
    'author': 'Sanjay Renduchintala',
    'author_email': 'san8055@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
